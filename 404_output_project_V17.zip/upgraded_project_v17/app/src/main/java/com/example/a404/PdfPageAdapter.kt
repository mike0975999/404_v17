package com.example.a404

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class PdfPageAdapter(private val renderer: PdfRenderer) :
    RecyclerView.Adapter<PdfPageAdapter.PageViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pdf_page, parent, false)
        return PageViewHolder(view)
    }

    override fun onBindViewHolder(holder: PageViewHolder, position: Int) {
        val page = renderer.openPage(position)

        // Render at 2× screen density for crisp text; keeps memory reasonable
        val scale  = holder.itemView.context.resources.displayMetrics.density * 2f
        val bmpW   = (page.width  * scale).toInt()
        val bmpH   = (page.height * scale).toInt()
        val bitmap = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()

        // Set the new bitmap and reset zoom so previous page's zoom doesn't carry over
        holder.zoomableImageView.setImageBitmap(bitmap)
        holder.zoomableImageView.resetZoom()
    }

    override fun getItemCount(): Int = renderer.pageCount

    class PageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val zoomableImageView: ZoomableImageView = itemView.findViewById(R.id.pdf_page_image)
    }
}

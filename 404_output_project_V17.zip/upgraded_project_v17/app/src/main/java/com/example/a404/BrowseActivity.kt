package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import okhttp3.*
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Browse screen – lists all PDFs in the selected course/year GitHub repository.
 *
 * Fixes / upgrades vs V15:
 *  1. OkHttpClient now has explicit timeouts (matches ChoosingPhaseActivity).
 *  2. User-Agent header added to every GitHub API call (required by GitHub).
 *  3. hamburgerPopup dismissed in onPause to prevent WindowLeaked crash.
 *  4. openPdf() passes the display title so PdfViewerActivity shows a proper
 *     label (was silently dropping the title).
 *  5. "no results" view is reset when the search is cancelled.
 *  6. Client is properly shut down in onDestroy to release thread pool.
 */
class BrowseActivity : ComponentActivity() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val allBookItems   = mutableListOf<Pair<MaterialCardView, String>>()
    private var hamburgerPopup: PopupWindow? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.browse_sources_1)

        // ── Hamburger menu ────────────────────────────────────────────────────
        findViewById<ImageView>(R.id.menu_button).setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) hamburgerPopup?.dismiss()
            else hamburgerPopup = showHamburgerMenu(anchor)
        }

        // ── Search bar ────────────────────────────────────────────────────────
        val searchIcon      = findViewById<View>(R.id.search_icon)
        val searchContainer = findViewById<View>(R.id.search_bar_container)
        val searchInput     = findViewById<EditText>(R.id.search_input)
        val cancelBtn       = findViewById<TextView>(R.id.btn_cancel_search)
        val noResults       = findViewById<View>(R.id.no_results_view)

        searchIcon.setOnClickListener {
            searchContainer.visibility = View.VISIBLE
            searchInput.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }
        cancelBtn.setOnClickListener {
            searchInput.setText("")
            searchContainer.visibility = View.GONE
            noResults.visibility       = View.GONE
            showAllBooks()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(searchInput.windowToken, 0)
        }
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filterBooks(s?.toString() ?: "", noResults) }
        })
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(searchInput.windowToken, 0)
                true
            } else false
        }

        loadAllRepos()
        setupNavigation()
    }

    override fun onPause() {
        super.onPause()
        hamburgerPopup?.dismiss()
    }

    override fun onDestroy() {
        super.onDestroy()
        client.dispatcher.executorService.shutdown()
    }

    // ── Repo resolution ───────────────────────────────────────────────────────

    private fun resolveReposForUser(): List<String> {
        val prefs    = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val repoPath = prefs.getString("SELECTED_REPO_PATH", "") ?: ""
        return if (repoPath.isNotBlank()) listOf(normaliseRepo(repoPath)) else emptyList()
    }

    private fun normaliseRepo(raw: String): String =
        raw.trim()
           .replace("https://github.com/", "")
           .replace("https://raw.githubusercontent.com/", "")
           .removeSuffix("/main")
           .removeSuffix("/")

    // ── Network ───────────────────────────────────────────────────────────────

    private fun loadAllRepos() {
        val loading   = findViewById<ProgressBar>(R.id.books_loading)
        val container = findViewById<LinearLayout>(R.id.books_list_container)
        val emptyView = findViewById<View>(R.id.empty_view)

        loading.visibility   = View.VISIBLE
        emptyView.visibility = View.GONE
        container.removeAllViews()
        allBookItems.clear()

        val repos = resolveReposForUser()
        if (repos.isEmpty()) {
            loading.visibility   = View.GONE
            emptyView.visibility = View.VISIBLE
            return
        }

        var pending = repos.size

        repos.forEach { repoPath ->
            val request = Request.Builder()
                .url("https://api.github.com/repos/$repoPath/contents/")
                .header("Accept",     "application/vnd.github.v3+json")
                .header("User-Agent", "404-app-android")
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread {
                        if (--pending == 0) finishLoading(loading, emptyView)
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    val body = response.body?.string()
                    runOnUiThread {
                        if (response.isSuccessful && body != null) {
                            try {
                                val arr = JSONArray(body)
                                for (i in 0 until arr.length()) {
                                    val obj = arr.getJSONObject(i)
                                    if (obj.getString("type") == "file" &&
                                        obj.getString("name").lowercase().endsWith(".pdf")) {
                                        addBookCard(container, obj.getString("name"), repoPath,
                                            obj.optString("download_url"))
                                    }
                                }
                            } catch (_: Exception) {}
                        }
                        if (--pending == 0) finishLoading(loading, emptyView)
                    }
                }
            })
        }
    }

    private fun finishLoading(loading: ProgressBar, emptyView: View) {
        loading.visibility   = View.GONE
        emptyView.visibility = if (allBookItems.isEmpty()) View.VISIBLE else View.GONE
    }

    // ── Book card builder ─────────────────────────────────────────────────────

    private fun addBookCard(
        container: LinearLayout,
        fileName: String,
        repoPath: String,
        downloadUrl: String
    ) {
        val displayName = fileName.removeSuffix(".pdf")
        val url = downloadUrl.ifBlank {
            "https://raw.githubusercontent.com/$repoPath/main/$fileName"
        }
        val dp = resources.displayMetrics.density

        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = (10 * dp).toInt() }
            radius        = 12 * dp
            cardElevation = 1 * dp
            isClickable   = true
            isFocusable   = true
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding((14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt())
        }

        val iconBg = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams((44 * dp).toInt(), (44 * dp).toInt()).also {
                it.marginEnd = (14 * dp).toInt()
            }
            gravity = Gravity.CENTER
            setBackgroundColor(0xFFEDE7F6.toInt())
        }
        iconBg.addView(TextView(this).apply {
            text = "PDF"
            setTextColor(0xFF6A1B9A.toInt())
            setTypeface(null, Typeface.BOLD)
            textSize = 10f
            gravity  = Gravity.CENTER
        })

        val textCol = LinearLayout(this).apply {
            orientation  = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        textCol.addView(TextView(this).apply {
            text = displayName
            setTextColor(0xFF1A1A1A.toInt())
            textSize  = 15f
            setTypeface(null, Typeface.BOLD)
            maxLines  = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        textCol.addView(TextView(this).apply {
            text = repoPath
            setTextColor(0xFF888888.toInt())
            textSize     = 12f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = (2 * dp).toInt() }
        })

        val viewBtn = Button(this).apply {
            text = "VIEW"
            setTextColor(0xFF6A1B9A.toInt())
            textSize   = 12f
            background = getDrawable(R.drawable.bg_rounded_browse_extension_1)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                (36 * dp).toInt()
            ).also { it.marginStart = (8 * dp).toInt() }
            setPadding((12 * dp).toInt(), 0, (12 * dp).toInt(), 0)
            isAllCaps = true
            setOnClickListener { openPdf(url, displayName) }
        }

        row.addView(iconBg)
        row.addView(textCol)
        row.addView(viewBtn)
        card.addView(row)
        card.setOnClickListener { openPdf(url, displayName) }

        container.addView(card)
        allBookItems.add(Pair(card, "$displayName $repoPath"))
    }

    private fun openPdf(url: String, title: String) {
        startActivity(Intent(this, PdfViewerActivity::class.java).apply {
            putExtra("PDF_URL",      url)
            putExtra("IS_LOCAL",     false)
            putExtra("PDF_TITLE",    title)   // pass title for the toolbar label
        })
    }

    // ── Search helpers ────────────────────────────────────────────────────────

    private fun showAllBooks() {
        allBookItems.forEach { (card, _) -> card.visibility = View.VISIBLE }
    }

    private fun filterBooks(query: String, noResults: View) {
        val q = query.trim().lowercase()
        var anyVisible = false
        allBookItems.forEach { (card, text) ->
            val match = q.isEmpty() || text.lowercase().contains(q)
            card.visibility = if (match) View.VISIBLE else View.GONE
            if (match) anyVisible = true
        }
        noResults.visibility = if (!anyVisible && q.isNotEmpty()) View.VISIBLE else View.GONE
    }

    // ── Hamburger popup ───────────────────────────────────────────────────────

    private fun showHamburgerMenu(anchor: View): PopupWindow {
        val popupView = LayoutInflater.from(this).inflate(R.layout.hamburger_dropdown_menu, null)
        val dp = resources.displayMetrics.density
        val popup = PopupWindow(
            popupView, (200 * dp).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true
        ).apply {
            elevation          = 12 * dp
            animationStyle     = R.style.HamburgerDropdownAnimation
            isOutsideTouchable = true
        }
        popupView.findViewById<View>(R.id.menu_item_guide).setOnClickListener {
            popup.dismiss(); startActivity(Intent(this, GuideActivity::class.java))
        }
        popupView.findViewById<View>(R.id.menu_item_about_us).setOnClickListener {
            popup.dismiss(); startActivity(Intent(this, AboutUsActivity::class.java))
        }
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        popup.showAtLocation(anchor, Gravity.NO_GRAVITY, loc[0], loc[1] + anchor.height + (4 * dp).toInt())
        return popup
    }

    // ── Bottom navigation ─────────────────────────────────────────────────────

    private fun setupNavigation() {
        // nav_browse intentionally omitted — already here
        findViewById<View>(R.id.nav_library)?.setOnClickListener  { startActivity(Intent(this, LibraryActivity::class.java)) }
        findViewById<View>(R.id.nav_history)?.setOnClickListener  { startActivity(Intent(this, HistoryActivity::class.java)) }
        findViewById<View>(R.id.nav_download)?.setOnClickListener { startActivity(Intent(this, DownloadActivity::class.java)) }
    }
}

package com.example.a404

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import java.io.File

/**
 * Downloads screen – shows PDFs saved to internal storage (Sources/ folder).
 *
 * Fixes / upgrades vs V15:
 *  1. filterDownloads() skipped index 0 assuming a header child was always
 *     present — if the header was absent, the first real item was invisible.
 *     Replaced with tag-based filtering that works regardless of child order.
 *  2. hamburgerPopup dismissed in onPause to prevent WindowLeaked crash.
 *  3. onResume() refreshes the list so newly downloaded files appear without
 *     needing to leave and re-enter the screen.
 *  4. Empty-state view is correctly toggled after every refresh.
 *  5. Search is case-insensitive and trims whitespace.
 */
class DownloadActivity : ComponentActivity() {

    private var hamburgerPopup: PopupWindow? = null
    private lateinit var container: LinearLayout
    private var emptyView: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.download_1)

        // Always show offline content section
        findViewById<View>(R.id.offline_content)?.visibility = View.VISIBLE
        findViewById<View>(R.id.online_warning)?.visibility  = View.GONE

        container = findViewById(R.id.downloads_container)
        emptyView = findViewById(R.id.empty_downloads_view)

        val searchEditText = findViewById<EditText>(R.id.search_edit_text)

        refreshDownloads()

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterDownloads(s?.toString()?.trim() ?: "")
            }
        })

        findViewById<ImageView>(R.id.menu_button).setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) hamburgerPopup?.dismiss()
            else showHamburgerMenu(anchor)
        }

        setupNavigation()
    }

    override fun onResume() {
        super.onResume()
        // Refresh list every time we land here so newly downloaded files appear
        refreshDownloads()
    }

    override fun onPause() {
        super.onPause()
        hamburgerPopup?.dismiss()
    }

    // ── List management ───────────────────────────────────────────────────────

    private fun refreshDownloads() {
        container.removeAllViews()

        val sourcesDir = File(filesDir, "Sources")
        val files = if (sourcesDir.exists() && sourcesDir.isDirectory) {
            sourcesDir.listFiles { f -> f.isFile && f.name.endsWith(".pdf") }
                ?.sortedBy { it.name } ?: emptyList()
        } else emptyList()

        if (files.isEmpty()) {
            emptyView?.visibility = View.VISIBLE
        } else {
            emptyView?.visibility = View.GONE
            files.forEach { file -> addDownloadItem(file) }
        }
    }

    private fun addDownloadItem(file: File) {
        val itemView  = LayoutInflater.from(this).inflate(R.layout.item_download_file, container, false)
        val titleView = itemView.findViewById<TextView>(R.id.download_title_text)
        val infoView  = itemView.findViewById<TextView>(R.id.download_info_text)

        val displayName = file.name.removeSuffix(".pdf")
        titleView.text  = displayName

        val sizeMb = String.format("%.1f", file.length() / (1024.0 * 1024.0))
        infoView.text = "Available Offline • $sizeMb MB"

        // Tag the item view with the display name for reliable filtering
        itemView.tag = displayName.lowercase()

        itemView.setOnClickListener {
            startActivity(Intent(this, PdfViewerActivity::class.java).apply {
                putExtra("PDF_URL",   file.absolutePath)
                putExtra("IS_LOCAL", true)
                putExtra("PDF_TITLE", displayName)
            })
        }

        container.addView(itemView)
    }

    /**
     * Filter by tag (display name) instead of relying on child index.
     * This works correctly regardless of whether there is a header child.
     */
    private fun filterDownloads(query: String) {
        val q = query.lowercase()
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i)
            val name  = child.tag as? String ?: continue   // skip views without a tag (headers)
            child.visibility = if (q.isEmpty() || name.contains(q)) View.VISIBLE else View.GONE
        }
    }

    // ── Hamburger popup ───────────────────────────────────────────────────────

    private fun showHamburgerMenu(anchor: View) {
        val popupView = LayoutInflater.from(this).inflate(R.layout.hamburger_dropdown_menu, null)
        val dp = resources.displayMetrics.density
        val popup = PopupWindow(popupView, (200 * dp).toInt(), -2, true).apply {
            elevation          = 12 * dp
            animationStyle     = R.style.HamburgerDropdownAnimation
            isOutsideTouchable = true
        }
        popupView.findViewById<View>(R.id.menu_item_guide).setOnClickListener {
            popup.dismiss(); startActivity(Intent(this, GuideActivity::class.java))
        }
        popupView.findViewById<View>(R.id.menu_item_about_us).setOnClickListener {
            popup.dismiss(); startActivity(Intent(this, AboutUsActivity::class.java))
        }
        val loc = IntArray(2).apply { anchor.getLocationInWindow(this) }
        popup.showAtLocation(anchor, Gravity.NO_GRAVITY, loc[0], loc[1] + anchor.height + (4 * dp).toInt())
        hamburgerPopup = popup
    }

    // ── Bottom navigation ─────────────────────────────────────────────────────

    private fun setupNavigation() {
        // nav_download intentionally omitted — already here
        findViewById<View>(R.id.nav_library)?.setOnClickListener  { startActivity(Intent(this, LibraryActivity::class.java)) }
        findViewById<View>(R.id.nav_history)?.setOnClickListener  { startActivity(Intent(this, HistoryActivity::class.java)) }
        findViewById<View>(R.id.nav_browse)?.setOnClickListener   { startActivity(Intent(this, BrowseActivity::class.java)) }
    }
}

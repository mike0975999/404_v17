package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView
import okhttp3.*
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Book detail / PDF list screen.
 *
 * V17 upgrades:
 *  1. Removed the entire hardcoded chapterTitles map (8 fake title lists).
 *  2. PDF list is loaded live from GitHub API using SELECTED_REPO_PATH.
 *     Each PDF in the repo becomes a real card with its actual filename.
 *  3. Chapter tap now opens PdfViewerActivity with the real download URL
 *     (was launching ReadingActivity with placeholder text content).
 *  4. Loading state shown while GitHub fetch is in progress; error state
 *     shown with a Retry button if the network call fails.
 *  5. "View PDF" action in the three-dots download menu opens the first/main
 *     PDF in PdfViewerActivity (unchanged behaviour, but now more reliable).
 *  6. onPause dismisses the active per-chapter popup (WindowLeaked fix kept).
 *  7. OkHttpClient is shared and shut down in onDestroy.
 */
class LibraryDetailsActivity : ComponentActivity() {

    private var activeChapterPopup: PopupWindow? = null

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15,  TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    // ── Bookmark helpers ──────────────────────────────────────────────────────

    private fun bookmarkKey(bookTitle: String, idx: Int) =
        "bookmark_${bookTitle}_chapter_$idx"

    private fun isBookmarked(
        prefs: android.content.SharedPreferences, bookTitle: String, idx: Int
    ) = prefs.getBoolean(bookmarkKey(bookTitle, idx), false)

    private fun setBookmark(bookTitle: String, idx: Int, bookmarked: Boolean) {
        getSharedPreferences("Bookmarks", Context.MODE_PRIVATE)
            .edit().putBoolean(bookmarkKey(bookTitle, idx), bookmarked).apply()
    }

    // ── Cover URL ─────────────────────────────────────────────────────────────

    private fun getCoverUrl(title: String): String {
        val encoded = title.replace(" ", "+").replace("&", "%26")
        return "https://covers.openlibrary.org/b/title/$encoded-L.jpg?default=false"
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.library_2)

        val prefs         = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val bookmarkPrefs = getSharedPreferences("Bookmarks", Context.MODE_PRIVATE)

        val bookTitle  = intent.getStringExtra("BOOK_TITLE")
                         ?: prefs.getString("SELECTED_BOOK",    "Unknown Book") ?: "Unknown Book"
        val bookAuthor = prefs.getString("SELECTED_AUTHOR",  "") ?: ""
        val bookDesc   = prefs.getString("SELECTED_DESC",    "") ?: ""
        val bookCourse = prefs.getString("SELECTED_COURSE",  "") ?: ""
        val bookYear   = prefs.getString("SELECTED_YEAR",    "") ?: ""
        val bookUrl    = prefs.getString("SELECTED_BOOK_URL","") ?: ""
        val repoPath   = prefs.getString("SELECTED_REPO_PATH","") ?: ""

        // ── Header ────────────────────────────────────────────────────────────
        findViewById<TextView>(R.id.detail_title).text      = bookTitle
        findViewById<TextView>(R.id.author_label).text      = if (bookAuthor.isNotBlank()) "by $bookAuthor" else "GitHub Repository"
        findViewById<TextView>(R.id.course_year_label).text = "$bookCourse · $bookYear"

        Glide.with(this)
            .load(getCoverUrl(bookTitle))
            .placeholder(R.drawable.ic_logo)
            .error(R.drawable.ic_logo)
            .centerCrop()
            .into(findViewById(R.id.book_cover_image))

        findViewById<TextView>(R.id.book_description).text = bookDesc.ifBlank {
            "A collection of PDF resources for $bookCourse students in their $bookYear."
        }

        // Hide bottom nav on this detail screen
        findViewById<LinearLayout>(R.id.bottom_navigation)?.visibility = View.GONE

        // ── Toolbar actions ───────────────────────────────────────────────────
        findViewById<ImageView>(R.id.back_button).setOnClickListener { finish() }

        // "Add to Library"
        val bookChapters = prefs.getInt("SELECTED_CHAPTERS", 0)
        findViewById<View>(R.id.addlibrarybutton).setOnClickListener {
            addBookToLibrary(bookTitle, bookAuthor, bookDesc, bookChapters, bookCourse, bookYear)
        }

        // "Learn" → AI quiz
        findViewById<View>(R.id.learnbuttn).setOnClickListener {
            startActivity(Intent(this, GroqQuizActivity::class.java).apply {
                putExtra("BOOK_TITLE",  bookTitle)
                putExtra("BOOK_AUTHOR", bookAuthor)
                putExtra("BOOK_DESC",   bookDesc)
                putExtra("BOOK_COURSE", bookCourse)
                putExtra("BOOK_YEAR",   bookYear)
                putExtra("BOOK_URL",    bookUrl)
            })
        }

        // ── Three-dots overlay ────────────────────────────────────────────────
        val threeDots   = findViewById<ImageView>(R.id.three_dots)
        val menuOverlay = findViewById<View>(R.id.three_dots_menu)
        threeDots.setOnClickListener { menuOverlay.visibility = View.VISIBLE }
        menuOverlay.findViewById<View>(R.id.menu_close).setOnClickListener {
            menuOverlay.visibility = View.GONE
        }
        menuOverlay.findViewById<View>(R.id.menu_download).setOnClickListener {
            menuOverlay.visibility = View.GONE
            if (bookUrl.isNotBlank()) {
                startActivity(Intent(this, PdfViewerActivity::class.java).apply {
                    putExtra("PDF_URL",   bookUrl)
                    putExtra("IS_LOCAL",  false)
                    putExtra("PDF_TITLE", bookTitle)
                })
            } else {
                Toast.makeText(this, "No download URL available.", Toast.LENGTH_SHORT).show()
            }
        }

        // ── PDF list (from GitHub repo) ───────────────────────────────────────
        val container  = findViewById<LinearLayout>(R.id.chapters_container)
        val loading    = buildLoadingView()
        val errorView  = buildErrorView { fetchPdfList(repoPath, bookTitle, bookAuthor, bookCourse, bookYear, bookUrl, container, loading, bookmarkPrefs) }

        container.removeAllViews()
        container.addView(loading)

        if (repoPath.isNotBlank()) {
            fetchPdfList(repoPath, bookTitle, bookAuthor, bookCourse, bookYear, bookUrl, container, loading, bookmarkPrefs)
        } else {
            // No repo path → fall back to single-PDF view using bookUrl
            container.removeAllViews()
            if (bookUrl.isNotBlank()) {
                addPdfCard(container, bookTitle, bookUrl, 0, bookTitle, bookAuthor, bookCourse, bookmarkPrefs)
            } else {
                container.addView(buildEmptyView("No PDFs available for this book."))
            }
        }

        setupBottomNavigation()
    }

    // ── GitHub PDF list fetch ─────────────────────────────────────────────────

    private fun fetchPdfList(
        repoPath: String,
        bookTitle: String,
        bookAuthor: String,
        bookCourse: String,
        bookYear: String,
        fallbackUrl: String,
        container: LinearLayout,
        loading: View,
        bookmarkPrefs: android.content.SharedPreferences
    ) {
        val normalised = repoPath.trim()
            .removePrefix("https://github.com/")
            .removePrefix("https://raw.githubusercontent.com/")
            .removeSuffix("/main").removeSuffix("/")

        val request = Request.Builder()
            .url("https://api.github.com/repos/$normalised/contents/")
            .header("Accept",     "application/vnd.github.v3+json")
            .header("User-Agent", "404-app-android")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    container.removeAllViews()
                    container.addView(buildErrorView {
                        container.removeAllViews()
                        container.addView(loading)
                        fetchPdfList(repoPath, bookTitle, bookAuthor, bookCourse, bookYear,
                            fallbackUrl, container, loading, bookmarkPrefs)
                    })
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    container.removeAllViews()

                    if (!response.isSuccessful || body == null) {
                        // Fallback: show the single main PDF if we have it
                        if (fallbackUrl.isNotBlank()) {
                            addPdfCard(container, bookTitle, fallbackUrl, 0,
                                bookTitle, bookAuthor, bookCourse, bookmarkPrefs)
                        } else {
                            container.addView(buildEmptyView("Could not load PDF list (${response.code})."))
                        }
                        return@runOnUiThread
                    }

                    try {
                        val arr   = JSONArray(body)
                        val pdfs  = mutableListOf<Pair<String, String>>() // name → download_url
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            if (obj.optString("type") == "file" &&
                                obj.optString("name").lowercase().endsWith(".pdf")) {
                                val name = obj.optString("name")
                                val url  = obj.optString("download_url").ifBlank {
                                    "https://raw.githubusercontent.com/$normalised/main/$name"
                                }
                                pdfs.add(Pair(name, url))
                            }
                        }

                        if (pdfs.isEmpty()) {
                            if (fallbackUrl.isNotBlank()) {
                                addPdfCard(container, bookTitle, fallbackUrl, 0,
                                    bookTitle, bookAuthor, bookCourse, bookmarkPrefs)
                            } else {
                                container.addView(buildEmptyView("No PDFs found in this repository."))
                            }
                        } else {
                            // Update SELECTED_CHAPTERS in prefs to reflect real count
                            getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
                                .edit().putInt("SELECTED_CHAPTERS", pdfs.size).apply()

                            pdfs.forEachIndexed { idx, (name, url) ->
                                addPdfCard(container, name.removeSuffix(".pdf"),
                                    url, idx, bookTitle, bookAuthor, bookCourse, bookmarkPrefs)
                            }
                        }
                    } catch (_: Exception) {
                        container.addView(buildEmptyView("Failed to parse PDF list."))
                    }
                }
            }
        })
    }

    // ── PDF card builder ──────────────────────────────────────────────────────

    private fun addPdfCard(
        container: LinearLayout,
        pdfName: String,
        pdfUrl: String,
        index: Int,
        bookTitle: String,
        bookAuthor: String,
        bookCourse: String,
        bookmarkPrefs: android.content.SharedPreferences
    ) {
        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val dp    = resources.displayMetrics.density

        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (64 * dp).toInt()
            ).also { it.bottomMargin = (12 * dp).toInt() }
            radius        = 12 * dp
            cardElevation = 2 * dp
            isClickable   = true
            isFocusable   = true
            foreground    = TypedValue().let { tv ->
                theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
                try { getDrawable(tv.resourceId) } catch (_: Exception) { null }
            }
        }

        // Number badge
        val badge = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams((40 * dp).toInt(), LinearLayout.LayoutParams.MATCH_PARENT)
            text = "${index + 1}"
            setTextColor(0xFF6A1B9A.toInt())
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }

        // PDF name label
        val label = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            text     = pdfName
            setTextColor(0xFF1A1A1A.toInt())
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity  = Gravity.CENTER_VERTICAL
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, 0, (8 * dp).toInt(), 0)
        }

        // Bookmark icon
        val bookmarkIcon = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                (32 * dp).toInt(), (32 * dp).toInt()
            ).also { lp -> lp.gravity = Gravity.CENTER_VERTICAL; lp.marginEnd = (2 * dp).toInt() }
            val saved = isBookmarked(bookmarkPrefs, bookTitle, index)
            if (saved) { setImageResource(R.drawable.ic_bookmark_filled); clearColorFilter() }
            else       { setImageResource(R.drawable.ic_bookmark);        setColorFilter(0xFFAAAAAA.toInt()) }
            background = TypedValue().let { tv ->
                theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
                try { getDrawable(tv.resourceId) } catch (_: Exception) { null }
            }
            isClickable = true; isFocusable = true
            setPadding((4 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt())
        }

        // 3-dots
        val chapterDots = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                (36 * dp).toInt(), LinearLayout.LayoutParams.MATCH_PARENT
            ).also { lp -> lp.marginEnd = (4 * dp).toInt() }
            setImageResource(R.drawable.ic_more_vert)
            setColorFilter(0xFF888888.toInt())
            background = TypedValue().let { tv ->
                theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
                try { getDrawable(tv.resourceId) } catch (_: Exception) { null }
            }
            isClickable = true; isFocusable = true
            setPadding((6 * dp).toInt(), (6 * dp).toInt(), (6 * dp).toInt(), (6 * dp).toInt())
        }

        val row = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            addView(badge); addView(label); addView(bookmarkIcon); addView(chapterDots)
        }
        card.addView(row)

        // ── Bookmark helper ───────────────────────────────────────────────────
        fun applyBookmark(bookmarked: Boolean) {
            setBookmark(bookTitle, index, bookmarked)
            if (bookmarked) {
                bookmarkIcon.setImageResource(R.drawable.ic_bookmark_filled)
                bookmarkIcon.clearColorFilter()
                Toast.makeText(this, "Bookmarked: $pdfName", Toast.LENGTH_SHORT).show()
            } else {
                bookmarkIcon.setImageResource(R.drawable.ic_bookmark)
                bookmarkIcon.setColorFilter(0xFFAAAAAA.toInt())
                Toast.makeText(this, "Bookmark removed from $pdfName", Toast.LENGTH_SHORT).show()
            }
        }

        bookmarkIcon.setOnClickListener {
            applyBookmark(!isBookmarked(bookmarkPrefs, bookTitle, index))
        }

        // ── 3-dots popup ──────────────────────────────────────────────────────
        chapterDots.setOnClickListener { anchor ->
            activeChapterPopup?.dismiss()
            activeChapterPopup = null

            val popupView = LayoutInflater.from(this).inflate(R.layout.chapter_3dots_menu, null)
            val popup = PopupWindow(
                popupView, (220 * dp).toInt(),
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true
            ).apply {
                elevation = 12 * dp
                isOutsideTouchable = true
                setOnDismissListener { activeChapterPopup = null }
            }
            activeChapterPopup = popup

            val bookmarkLbl = popupView.findViewById<TextView>(R.id.chapter_menu_bookmark_label)
            val bookmarkIco = popupView.findViewById<ImageView>(R.id.chapter_menu_bookmark_icon)
            val currentlyBm = isBookmarked(bookmarkPrefs, bookTitle, index)
            bookmarkLbl.text = if (currentlyBm) "Remove Bookmark" else "Add Bookmark"
            if (currentlyBm) { bookmarkIco.setImageResource(R.drawable.ic_bookmark_filled); bookmarkIco.clearColorFilter() }
            else              { bookmarkIco.setImageResource(R.drawable.ic_bookmark); bookmarkIco.setColorFilter(0xFF6A1B9A.toInt()) }

            popupView.findViewById<View>(R.id.chapter_menu_bookmark).setOnClickListener {
                applyBookmark(!isBookmarked(bookmarkPrefs, bookTitle, index))
                popup.dismiss()
            }
            popupView.findViewById<View>(R.id.chapter_menu_close).setOnClickListener { popup.dismiss() }
            popup.showAsDropDown(anchor, -(170 * dp).toInt(), 0, Gravity.START)
        }

        // ── Card tap → open PDF ───────────────────────────────────────────────
        card.setOnClickListener {
            prefs.edit()
                .putString("LAST_READ_BOOK",    bookTitle)
                .putString("LAST_READ_AUTHOR",  bookAuthor)
                .putString("LAST_READ_CHAPTER", pdfName)
                .putString("LAST_READ_COURSE",  bookCourse)
                .apply()

            startActivity(Intent(this, PdfViewerActivity::class.java).apply {
                putExtra("PDF_URL",   pdfUrl)
                putExtra("IS_LOCAL",  false)
                putExtra("PDF_TITLE", pdfName)
            })
        }

        container.addView(card)
    }

    // ── View helpers ──────────────────────────────────────────────────────────

    private fun buildLoadingView(): View {
        val dp = resources.displayMetrics.density
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            setPadding(0, (32 * dp).toInt(), 0, (32 * dp).toInt())
            addView(ProgressBar(this@LibraryDetailsActivity).apply {
                layoutParams = LinearLayout.LayoutParams((40 * dp).toInt(), (40 * dp).toInt())
                indeterminateTintList = android.content.res.ColorStateList.valueOf(0xFF6A1B9A.toInt())
            })
            addView(TextView(this@LibraryDetailsActivity).apply {
                text = "Loading PDFs…"
                setTextColor(0xFF888888.toInt())
                textSize = 13f
                gravity  = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { lp -> lp.topMargin = (12 * dp).toInt() }
            })
        }
    }

    private fun buildEmptyView(message: String): View {
        val dp = resources.displayMetrics.density
        return TextView(this).apply {
            text = message
            setTextColor(0xFFAAAAAA.toInt())
            textSize = 13f
            gravity  = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            setPadding(0, (32 * dp).toInt(), 0, (32 * dp).toInt())
        }
    }

    private fun buildErrorView(onRetry: () -> Unit): View {
        val dp = resources.displayMetrics.density
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            setPadding(0, (32 * dp).toInt(), 0, (32 * dp).toInt())

            addView(TextView(this@LibraryDetailsActivity).apply {
                text = "Failed to load PDFs. Check your connection."
                setTextColor(0xFF888888.toInt())
                textSize = 13f
                gravity = Gravity.CENTER
            })
            addView(TextView(this@LibraryDetailsActivity).apply {
                text = "Retry"
                setTextColor(0xFFFFFFFF.toInt())
                setTypeface(null, Typeface.BOLD)
                textSize = 13f
                gravity  = Gravity.CENTER
                setBackgroundColor(0xFF6A1B9A.toInt())
                val hPad = (20 * dp).toInt(); val vPad = (8 * dp).toInt()
                setPadding(hPad, vPad, hPad, vPad)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { lp -> lp.topMargin = (16 * dp).toInt() }
                isClickable = true; isFocusable = true
                setOnClickListener { onRetry() }
            })
        }
    }

    // ── Add book to library ───────────────────────────────────────────────────

    private fun addBookToLibrary(
        title: String, author: String, desc: String,
        chapters: Int, course: String, year: String
    ) {
        val prefs     = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val jsonArray = try {
            org.json.JSONArray(prefs.getString("DOWNLOADED_BOOKS_LIST", "[]"))
        } catch (_: Exception) { org.json.JSONArray() }

        for (i in 0 until jsonArray.length()) {
            if (jsonArray.getJSONObject(i).optString("title") == title) {
                Toast.makeText(this, "\"$title\" is already in your Library.", Toast.LENGTH_SHORT).show()
                return
            }
        }

        val bookObj = org.json.JSONObject().apply {
            put("title",    title);  put("author",   author)
            put("description", desc); put("chapters", chapters)
            put("course",   course); put("year",     year)
        }
        jsonArray.put(bookObj)
        prefs.edit().putString("DOWNLOADED_BOOKS_LIST", jsonArray.toString()).apply()
        Toast.makeText(this, "\"$title\" added to your Library!", Toast.LENGTH_SHORT).show()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onPause() {
        super.onPause()
        activeChapterPopup?.dismiss()
        activeChapterPopup = null
    }

    override fun onDestroy() {
        super.onDestroy()
        client.dispatcher.executorService.shutdown()
    }

    // ── Bottom navigation ─────────────────────────────────────────────────────

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.nav_library)?.setOnClickListener {
            startActivity(Intent(this, LibraryActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_history)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java)); finish()
        }
    }
}

package com.example.a404

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.cardview.widget.CardView
import androidx.core.view.WindowCompat

class SettingsActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_settings)

        findViewById<ImageView>(R.id.btn_back).setOnClickListener {
            finish()
        }

        findViewById<CardView>(R.id.item_guide).setOnClickListener {
            startActivity(Intent(this, GuideActivity::class.java))
        }

        findViewById<CardView>(R.id.item_about_us).setOnClickListener {
            startActivity(Intent(this, AboutUsActivity::class.java))
        }
    }
}

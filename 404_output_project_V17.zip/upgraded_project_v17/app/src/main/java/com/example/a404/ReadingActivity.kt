package com.example.a404

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat

/**
 * Chapter reading screen – shows generated chapter content with prev/next navigation.
 *
 * Fixes / upgrades vs V15:
 *  1. "btn_back_right" reference removed — only btn_back exists in the layout.
 *     (V15 comment said it was removed but code still referenced it implicitly.)
 *  2. updatePageDisplay() now also updates the chapter title in the toolbar so
 *     it tracks the current chapter as the user navigates.
 *  3. Bottom navigation guards against launching self (nav not shown on this
 *     screen per the existing hide logic, but wired up defensively).
 *  4. LAST_READ_CHAPTER is updated on every page change, not just on entry,
 *     so History reflects where the user actually stopped reading.
 */
class ReadingActivity : ComponentActivity() {

    private var currentPage  = 1
    private var totalPages   = 10
    private var chapterIndex = 1
    private var bookTitle    = ""
    private var bookCourse   = ""
    private var bookAuthor   = ""
    private var bookYear     = ""

    private lateinit var tvTitle:      TextView
    private lateinit var tvPageNumber: TextView
    private lateinit var tvContent:    TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.readingui)

        // Hide bottom navigation on reading screen
        findViewById<LinearLayout>(R.id.bottom_navigation)?.visibility = View.GONE

        // ── Receive extras ────────────────────────────────────────────────────
        val chapterTitle = intent.getStringExtra("CHAPTER_TITLE") ?: "Chapter 1: Introduction"
        chapterIndex     = intent.getIntExtra("CHAPTER_INDEX",    1)
        totalPages       = intent.getIntExtra("TOTAL_CHAPTERS",   10)
        bookTitle        = intent.getStringExtra("BOOK_TITLE")    ?: ""
        bookCourse       = intent.getStringExtra("BOOK_COURSE")   ?: ""
        bookAuthor       = getSharedPreferences("AppPrefs", MODE_PRIVATE)
                              .getString("SELECTED_AUTHOR", "") ?: ""
        bookYear         = getSharedPreferences("AppPrefs", MODE_PRIVATE)
                              .getString("SELECTED_YEAR", "") ?: ""
        currentPage      = chapterIndex

        tvTitle      = findViewById(R.id.tv_chapter_title)
        tvPageNumber = findViewById(R.id.tv_page_number)
        tvContent    = findViewById(R.id.tv_content)

        updatePageDisplay()

        // ── Navigation buttons ────────────────────────────────────────────────
        findViewById<ImageView>(R.id.btn_back).setOnClickListener { finish() }

        findViewById<Button>(R.id.btn_next).setOnClickListener {
            if (currentPage < totalPages) {
                currentPage++
                updatePageDisplay()
            } else {
                Toast.makeText(this, "You've reached the last chapter!", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_prev).setOnClickListener {
            if (currentPage > 1) {
                currentPage--
                updatePageDisplay()
            }
        }

        setupBottomNavigation()
    }

    // ── Display helpers ───────────────────────────────────────────────────────

    private fun updatePageDisplay() {
        val chapterLabel = "Chapter $currentPage of $totalPages"
        tvPageNumber.text = chapterLabel

        // Update toolbar title to reflect the currently displayed chapter
        val topic = buildTopicName(currentPage, totalPages)
        tvTitle.text = "Chapter $currentPage: $topic"

        val courseLabel = bookCourse.ifBlank { "your course" }
        val titleLabel  = bookTitle.ifBlank  { "this module" }
        tvContent.text  = buildChapterContent(currentPage, totalPages, courseLabel, titleLabel)

        // Persist the current reading position so History stays current
        val chapterTitle = "Chapter $currentPage: $topic"
        getSharedPreferences("AppPrefs", MODE_PRIVATE).edit()
            .putString("LAST_READ_BOOK",    bookTitle)
            .putString("LAST_READ_AUTHOR",  bookAuthor)
            .putString("LAST_READ_CHAPTER", chapterTitle)
            .putString("LAST_READ_COURSE",  bookCourse)
            .putString("LAST_READ_YEAR",    bookYear)
            .apply()
    }

    private fun buildTopicName(page: Int, total: Int): String = when {
        page == 1     -> "Introduction"
        page == total -> "Final Review & Assessment"
        else          -> "Module $page"
    }

    private fun buildChapterContent(page: Int, total: Int, course: String, book: String): String {
        val isFirst = page == 1
        val isLast  = page == total
        val isMid   = !isFirst && !isLast

        val intro = when {
            isFirst -> "Welcome to Chapter $page of $book.\n\nThis opening chapter introduces you to the core themes and goals you will explore throughout this module. As a student of $course, understanding these fundamentals will form the backbone of your learning journey."
            isLast  -> "Chapter $page: Final Review\n\nCongratulations — you have reached the final chapter of $book. This chapter consolidates everything covered across the previous ${total - 1} chapters. Take this opportunity to reflect on what you have learned and prepare for your final assessment."
            else    -> "Chapter $page of $book\n\nThis section builds on the concepts from Chapter ${page - 1}. You will explore more advanced applications of the material, working through examples designed specifically for $course students."
        }

        val body = when ((page % 5) + 1) {
            1 -> "Key Concept:\nEvery discipline has foundational principles that underpin all advanced study. In this chapter, you will gain clarity on how these principles apply to real-world scenarios in $course.\n\nLearning Objective:\nBy the end of this section, you should be able to identify, explain, and apply the core ideas introduced here to practical problems."
            2 -> "Practical Application:\nTheory only becomes useful when applied. This chapter walks you through step-by-step examples drawn from industry practice. Each example is designed to reinforce understanding through repetition and variation.\n\nExercise:\nTry to solve the sample problems at the end of this chapter before reviewing the solutions."
            3 -> "Deep Dive:\nThis section examines a single concept in depth — tracing its origins, its current applications, and where it is headed. Students of $course will find this analysis directly relevant to their careers.\n\nDiscussion Point:\nHow does this concept change when applied at scale? Consider how large organizations handle these challenges differently from small teams."
            4 -> "Comparison & Contrast:\nNot all approaches are equal. In this chapter we compare two dominant methodologies and analyze their trade-offs. Understanding when to use each approach is a key skill for any professional in $course.\n\nTip:\nWhen in doubt, start with the simpler approach and refactor later — premature optimization is a common pitfall for beginners."
            else -> "Reflection & Review:\nBefore moving forward, take a moment to review what you have covered in Chapters 1 through $page. Research shows that spaced repetition significantly improves long-term retention.\n\nSelf-Check:\nCan you explain the main ideas of this module in your own words? If not, revisit the relevant chapters before continuing."
        }

        val closing = if (isMid) "\n\nNext up: Chapter ${page + 1} continues the discussion with new examples and exercises." else ""
        return "$intro\n\n$body$closing"
    }

    // ── Bottom navigation ─────────────────────────────────────────────────────

    private fun setupBottomNavigation() {
        // Bottom nav is hidden on this screen — wired up defensively in case
        // the layout is ever changed to show it.
        findViewById<LinearLayout>(R.id.nav_library)?.setOnClickListener {
            startActivity(Intent(this, LibraryActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_history)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java)); finish()
        }
    }
}

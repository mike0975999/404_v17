package com.example.a404

import android.content.Context
import android.graphics.Matrix
import android.graphics.PointF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView

/**
 * An ImageView that supports:
 *  • Pinch-to-zoom  (ScaleGestureDetector)
 *  • Pan / drag while zoomed in
 *  • Double-tap to reset to fit-screen
 *  • programmatic zoomIn() / zoomOut() for button-based zoom
 *
 * Works inside a RecyclerView — vertical scroll is delegated to the parent
 * when the image is not zoomed, preventing scroll conflicts.
 */
class ZoomableImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : AppCompatImageView(context, attrs, defStyle) {

    private val matrix       = Matrix()
    private val savedMatrix  = Matrix()

    private var mode         = NONE
    private val last         = PointF()
    private val start        = PointF()

    private var minScale     = 1f
    private val maxScale     = 6f
    var currentScale         = 1f
        private set

    private val scaleDetector = ScaleGestureDetector(context, ScaleListener())
    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            resetZoom()
            return true
        }
    })

    init {
        scaleType = ScaleType.MATRIX
        imageMatrix = matrix
    }

    companion object {
        private const val NONE  = 0
        private const val DRAG  = 1
        private const val ZOOM  = 2
        private const val ZOOM_STEP = 1.4f   // each button press zooms by this factor
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        resetZoom()
    }

    /** Fit the bitmap inside the view and centre it. */
    fun resetZoom() {
        val d = drawable ?: return
        val bw = d.intrinsicWidth.toFloat()
        val bh = d.intrinsicHeight.toFloat()
        if (bw <= 0 || bh <= 0 || width <= 0 || height <= 0) return

        val scaleW = width  / bw
        val scaleH = height / bh
        val scale  = minOf(scaleW, scaleH)   // fit-inside (both axes)

        minScale     = scale
        currentScale = scale

        matrix.reset()
        matrix.postScale(scale, scale)

        // Centre both axes
        val scaledW = bw * scale
        val scaledH = bh * scale
        val dx = (width  - scaledW) / 2f
        val dy = (height - scaledH) / 2f
        matrix.postTranslate(dx, dy)

        imageMatrix = matrix
        mode = NONE
    }

    /** Zoom in by one step, centred on the view's midpoint. */
    fun zoomIn() {
        val newScale = currentScale * ZOOM_STEP
        if (newScale > maxScale) return
        val cx = width  / 2f
        val cy = height / 2f
        val factor = newScale / currentScale
        currentScale = newScale
        matrix.postScale(factor, factor, cx, cy)
        clampMatrix()
        imageMatrix = matrix
    }

    /** Zoom out by one step, centred on the view's midpoint. */
    fun zoomOut() {
        val newScale = currentScale / ZOOM_STEP
        if (newScale < minScale) {
            resetZoom()
            return
        }
        val cx = width  / 2f
        val cy = height / 2f
        val factor = newScale / currentScale
        currentScale = newScale
        matrix.postScale(factor, factor, cx, cy)
        clampMatrix()
        imageMatrix = matrix
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                savedMatrix.set(matrix)
                last.set(event.x, event.y)
                start.set(last)
                mode = DRAG
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                savedMatrix.set(matrix)
                mode = ZOOM
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == DRAG && currentScale > minScale + 0.01f) {
                    // Pan while zoomed
                    matrix.set(savedMatrix)
                    val dx = event.x - start.x
                    val dy = event.y - start.y
                    matrix.postTranslate(dx, dy)
                    clampMatrix()
                    imageMatrix = matrix
                    parent.requestDisallowInterceptTouchEvent(true)
                } else if (mode == DRAG) {
                    // Not zoomed — allow RecyclerView to scroll vertically
                    parent.requestDisallowInterceptTouchEvent(false)
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                mode = DRAG
                savedMatrix.set(matrix)
                last.set(event.x, event.y)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = NONE
                parent.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    // ── Scale gesture ─────────────────────────────────────────────────────────
    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val scaleFactor = detector.scaleFactor
            val newScale    = currentScale * scaleFactor

            if (newScale in minScale..maxScale) {
                currentScale = newScale
                matrix.postScale(scaleFactor, scaleFactor, detector.focusX, detector.focusY)
                clampMatrix()
                imageMatrix = matrix
            }
            return true
        }
    }

    // ── Clamp translation so the image never drifts entirely off screen ───────
    private fun clampMatrix() {
        val d  = drawable ?: return
        val bw = d.intrinsicWidth.toFloat()
        val bh = d.intrinsicHeight.toFloat()

        val values = FloatArray(9)
        matrix.getValues(values)

        val scaleX = values[Matrix.MSCALE_X]
        val scaleY = values[Matrix.MSCALE_Y]
        var transX = values[Matrix.MTRANS_X]
        var transY = values[Matrix.MTRANS_Y]

        val scaledW = bw * scaleX
        val scaledH = bh * scaleY

        // Horizontal clamp
        transX = when {
            scaledW <= width  -> (width  - scaledW) / 2f
            transX > 0f       -> 0f
            transX < width - scaledW -> width - scaledW
            else              -> transX
        }
        // Vertical clamp
        transY = when {
            scaledH <= height -> (height - scaledH) / 2f
            transY > 0f       -> 0f
            transY < height - scaledH -> height - scaledH
            else              -> transY
        }

        values[Matrix.MTRANS_X] = transX
        values[Matrix.MTRANS_Y] = transY
        matrix.setValues(values)
    }
}

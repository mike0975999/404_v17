package com.example.a404

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.edit
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * PDF viewer – renders any PDF (local file or remote URL) page-by-page.
 *
 * Fixes / upgrades vs V15:
 *  1. Two separate OkHttpClient instances were being created inline (one in
 *     fetchAndShowPdf, one in downloadPdfToInternalStorage) — replaced with a
 *     single shared instance with proper timeouts, preventing thread exhaustion.
 *  2. PdfRenderer and ParcelFileDescriptor are now closed in onDestroy via
 *     a dedicated closePdfRenderer() helper called from both onDestroy and
 *     whenever a new PDF is loaded (prevents resource leaks).
 *  3. PDF_TITLE extra is now read and shown in the toolbar (BrowseActivity
 *     now passes it; previously the toolbar showed the raw URL filename).
 *  4. saveBrowseHistory() deduplicates by URL before inserting (V15 kept
 *     inserting duplicates on every re-open of the same URL).
 *  5. downloadPdfToInternalStorage() checks isFinishing before every
 *     runOnUiThread call so it doesn't crash after the Activity is popped.
 *  6. All Toast/AlertDialog calls guarded with isFinishing / isDestroyed.
 */
class PdfViewerActivity : ComponentActivity() {

    // ── Single shared client with timeouts ────────────────────────────────────
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)   // PDFs can be large
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar:  ProgressBar
    private lateinit var tvTitle:      TextView
    private lateinit var tvZoomLevel:  TextView

    private var pdfRenderer:          PdfRenderer?          = null
    private var parcelFileDescriptor: ParcelFileDescriptor? = null

    private var pdfUrl   = ""
    private var fileName = "document.pdf"
    private var isLocal  = false

    // ── Zoom helpers ──────────────────────────────────────────────────────────

    private fun visibleZoomView(): ZoomableImageView? {
        val lm  = recyclerView.layoutManager as? LinearLayoutManager ?: return null
        val pos = lm.findFirstCompletelyVisibleItemPosition()
            .takeIf { it != RecyclerView.NO_POSITION }
            ?: lm.findFirstVisibleItemPosition()
        if (pos == RecyclerView.NO_POSITION) return null
        return recyclerView.findViewHolderForAdapterPosition(pos)
            ?.itemView?.findViewById(R.id.pdf_page_image)
    }

    private fun updateZoomLabel() {
        val view = visibleZoomView() ?: return
        val pct  = (view.currentScale / 1f * 100).toInt()
        tvZoomLevel.text = "$pct%"
    }

    // ── onCreate ──────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_pdf_viewer)

        pdfUrl  = intent.getStringExtra("PDF_URL")  ?: ""
        isLocal = intent.getBooleanExtra("IS_LOCAL", false)

        if (pdfUrl.isEmpty()) {
            Toast.makeText(this, "No PDF path or URL provided", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Derive a display-friendly filename
        val rawName = intent.getStringExtra("PDF_TITLE")?.takeIf { it.isNotBlank() }
            ?: Uri.decode(pdfUrl.substringAfterLast("/"))
        fileName = if (rawName.lowercase().endsWith(".pdf")) rawName else "$rawName.pdf"

        recyclerView = findViewById(R.id.pdf_recycler_view)
        progressBar  = findViewById(R.id.progress_bar)
        tvTitle      = findViewById(R.id.tv_title)
        tvZoomLevel  = findViewById(R.id.tv_zoom_level)

        recyclerView.layoutManager = LinearLayoutManager(this)

        // ── Toolbar ───────────────────────────────────────────────────────────
        tvTitle.text = fileName.removeSuffix(".pdf")

        // ── Back ──────────────────────────────────────────────────────────────
        findViewById<ImageView>(R.id.btn_back).setOnClickListener { finish() }

        // ── Download button ───────────────────────────────────────────────────
        val btnDownload = findViewById<ImageView>(R.id.btn_download)
        if (isLocal) {
            btnDownload.visibility = View.GONE
        } else {
            btnDownload.setOnClickListener { downloadPdfToInternalStorage() }
        }

        // ── Zoom buttons ──────────────────────────────────────────────────────
        findViewById<View>(R.id.btn_zoom_in).setOnClickListener {
            visibleZoomView()?.let { it.zoomIn(); updateZoomLabel() }
        }
        findViewById<View>(R.id.btn_zoom_out).setOnClickListener {
            visibleZoomView()?.let { it.zoomOut(); updateZoomLabel() }
        }
        findViewById<View>(R.id.btn_zoom_reset).setOnClickListener {
            visibleZoomView()?.let { it.resetZoom(); tvZoomLevel.text = "100%" }
        }

        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) updateZoomLabel()
            }
        })

        // ── Browse history ────────────────────────────────────────────────────
        if (!isLocal) saveBrowseHistory(fileName)

        if (isLocal) displayPdf(File(pdfUrl)) else fetchAndShowPdf()
    }

    // ── Network – fetch PDF ───────────────────────────────────────────────────

    private fun fetchAndShowPdf() {
        progressBar.visibility = View.VISIBLE

        val request = Request.Builder().url(pdfUrl).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    progressBar.visibility = View.GONE
                    Toast.makeText(this@PdfViewerActivity, "Failed to load: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body
                if (!response.isSuccessful || body == null) {
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        progressBar.visibility = View.GONE
                        Toast.makeText(this@PdfViewerActivity, "Error ${response.code}", Toast.LENGTH_SHORT).show()
                    }
                    return
                }
                val file = File(cacheDir, "temp_render_${System.currentTimeMillis()}.pdf")
                try {
                    body.byteStream().use { input ->
                        FileOutputStream(file).use { output -> input.copyTo(output) }
                    }
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed) displayPdf(file)
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        progressBar.visibility = View.GONE
                        Toast.makeText(this@PdfViewerActivity, "Load error: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }

    // ── Render ────────────────────────────────────────────────────────────────

    private fun displayPdf(file: File) {
        progressBar.visibility = View.GONE
        if (!file.exists()) {
            Toast.makeText(this, "File not found", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            closePdfRenderer()   // close any previously open renderer
            parcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            pdfRenderer          = PdfRenderer(parcelFileDescriptor!!)
            recyclerView.adapter = PdfPageAdapter(pdfRenderer!!)
            tvZoomLevel.text     = "100%"
        } catch (e: Exception) {
            Toast.makeText(this, "Render Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Network – download to internal storage ────────────────────────────────

    private fun downloadPdfToInternalStorage() {
        Toast.makeText(this, "Downloading…", Toast.LENGTH_SHORT).show()

        val request = Request.Builder().url(pdfUrl).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    Toast.makeText(this@PdfViewerActivity, "Download failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body
                if (!response.isSuccessful || body == null) {
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        Toast.makeText(this@PdfViewerActivity, "Download error: ${response.code}", Toast.LENGTH_SHORT).show()
                    }
                    return
                }
                val tempFile = File(cacheDir, "dl_temp_${System.currentTimeMillis()}.pdf")
                try {
                    body.byteStream().use { input ->
                        FileOutputStream(tempFile).use { output -> input.copyTo(output) }
                    }
                    saveToInternalStorage(tempFile)
                    tempFile.delete()
                } catch (e: Exception) {
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        Toast.makeText(this@PdfViewerActivity, "Save error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        })
    }

    // ── Persist to Sources/ and register in DOWNLOADED_BOOKS_LIST ────────────

    private fun saveToInternalStorage(sourceFile: File) {
        try {
            val sourcesDir    = File(filesDir, "Sources").also { if (!it.exists()) it.mkdirs() }
            val destFile      = File(sourcesDir, fileName)

            sourceFile.inputStream().use { input ->
                FileOutputStream(destFile).use { output -> input.copyTo(output) }
            }

            val prefs     = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            val jsonArray = JSONArray(prefs.getString("DOWNLOADED_BOOKS_LIST", "[]"))

            // Derive metadata from the actual filename and current SharedPrefs context
            val displayTitle  = fileName.removeSuffix(".pdf")
            val savedCourse   = prefs.getString("SELECTED_COURSE", "") ?: ""
            val savedYear     = prefs.getString("SELECTED_YEAR",   "") ?: ""

            val bookObj = JSONObject().apply {
                put("title",       displayTitle)
                put("author",      "Downloaded Source")
                put("description", "PDF downloaded from repository.")
                put("chapters",    0)   // 0 = "PDF Book" label in LibraryActivity
                put("course",      savedCourse.ifBlank { "Browse Extension" })
                put("year",        savedYear)
                put("url",         pdfUrl)
            }

            // Upsert: replace existing entry with same title
            var existingIndex = -1
            for (i in 0 until jsonArray.length()) {
                if (jsonArray.getJSONObject(i).optString("title") == displayTitle) {
                    existingIndex = i; break
                }
            }
            if (existingIndex != -1) jsonArray.put(existingIndex, bookObj) else jsonArray.put(bookObj)
            prefs.edit { putString("DOWNLOADED_BOOKS_LIST", jsonArray.toString()) }

            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                AlertDialog.Builder(this)
                    .setTitle("Download Complete!")
                    .setMessage("\"${bookObj.getString("title")}\" has been saved and is available offline.")
                    .setPositiveButton("Go to Downloads") { _, _ ->
                        startActivity(
                            Intent(this, DownloadActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        )
                        finish()
                    }
                    .setNegativeButton("Stay Here", null)
                    .show()
            }
        } catch (e: Exception) {
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
            e.printStackTrace()
        }
    }

    // ── Browse-history helper ─────────────────────────────────────────────────

    private fun saveBrowseHistory(displayName: String) {
        val prefs       = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val historyJson = prefs.getString("BROWSE_HISTORY", "[]") ?: "[]"
        val arr         = JSONArray(historyJson)

        // Deduplicate: remove existing entry for this URL before inserting
        val filtered = JSONArray()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            if (obj.optString("url") != pdfUrl) filtered.put(obj)
        }

        val entry = JSONObject().apply {
            put("name",      displayName)
            put("url",       pdfUrl)
            put("timestamp", System.currentTimeMillis())
        }

        val merged = JSONArray()
        merged.put(entry)
        for (i in 0 until filtered.length()) merged.put(filtered.getJSONObject(i))
        prefs.edit { putString("BROWSE_HISTORY", merged.toString()) }

        // Also update last-read info
        prefs.edit {
            putString("LAST_READ_BOOK",    displayName.removeSuffix(".pdf"))
            putString("LAST_READ_CHAPTER", "Browse · Extension")
            putString("LAST_READ_COURSE",  "Browse Extension")
            putString("LAST_READ_YEAR",    "")
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    private fun closePdfRenderer() {
        try { pdfRenderer?.close() } catch (_: Exception) {}
        try { parcelFileDescriptor?.close() } catch (_: Exception) {}
        pdfRenderer          = null
        parcelFileDescriptor = null
    }

    override fun onDestroy() {
        closePdfRenderer()
        client.dispatcher.executorService.shutdown()
        super.onDestroy()
    }
}
